﻿using System;
using System.Collections.Generic;

namespace MAFIA
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int n, i, buff;
            bool AnonVote = false;
            Console.WriteLine("Сколько будет игроков?");
        Input_n_Again:
            try { n = Convert.ToInt32(Console.ReadLine()); }
            catch { Console.WriteLine("Необходимо ввести цифру. Попробуйте ещё раз."); goto Input_n_Again; }
            if (n > 10 || n < 3) { Console.WriteLine("Игроков должно быть от 3 до 10. Введите колличество игроков ещё раз."); goto Input_n_Again; }

            Console.WriteLine("Будет ли анонимное голосование?");
            string Sbuff = Console.ReadLine();
            if (Sbuff == "да" || Sbuff == "Да" || Sbuff == "LF" || Sbuff == "lf" || Sbuff == "yes" || Sbuff == "Yes" || Sbuff == "y" || Sbuff == "Y" || Sbuff == "1") { AnonVote = true; }
            else { Console.WriteLine("Само голосование будет проводиться обособленно от терминала. Необходимо будет только ввести номер выбранного игрока."); }

            Dictionary<int, string> ListOfPlayers = GetPlayersRolesList(GetNumberRolesList(n));
            Console.WriteLine("Сейчас будет распределение ролей. Игроки должны по очереди подходить к терминалу, чтобы узнать их роль в игре. Никто, кроме игрока не должен видеть, что происходит на экране. \n\tДля продолжения нажмите любую кнопку...");
            Console.ReadKey(true);
            Console.Clear();
            //ETAn PACnPEDEJlEHu9 POJlEu
            for (i = 0; i < n; i++)
            {
                Console.WriteLine("Введите ваш номер игрока, чтобы узнать вашу роль в игре. ");
            KnowMyRole:
                try { buff = Convert.ToInt32(Console.ReadLine()); }
                catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto KnowMyRole; }
                if (buff < 1 || buff > n) { Console.WriteLine("Максимальное колличество игроков: " + n + ". Попробуйте ввести ещё раз. "); goto KnowMyRole; }
                Console.WriteLine("Ваша роль: " + ListOfPlayers[buff - 1]);
                if (ListOfPlayers[buff - 1] == "Mafia")
                {
                    Console.WriteLine("Игроки в вашей команде: ");
                    int li;
                    Console.WriteLine("\tВы");
                    for (li = 0; li < n; li++)
                    {
                        if (ListOfPlayers[li] == "Mafia" && li != (buff - 1)) { Console.WriteLine("\tИгрок " + (li + 1) + " Mafia."); }
                    }
                    Console.WriteLine("Больше нет игроков в команде Mafia.");
                }
                Console.WriteLine("Нажми любую кнопку, чтобы стереть содержимое терминала, и передать управление следующему игроку.");
                Console.ReadKey(true);
                Console.Clear();
            }
            buff = 0;
            Dictionary<int, int> ListChoosed = new Dictionary<int, int>();
            int LosedPlayer;
            int DoctorChoose;
            Random rnd = new Random();

            Console.WriteLine("Игра начинается... \nНаступает Новый день. \nИгроки знакомятся друг с другом...");
            while (ListOfPlayers.Count > 2 && ListOfPlayers.ContainsValue("Mafia"))
            {
                DoctorChoose = 0;
                LosedPlayer = 0;
                ListChoosed.Clear();

                Console.WriteLine("Нажмите любую клавишу, если день прошёл.");
                Console.ReadKey(true);

                Console.WriteLine("Наступает ночь. Каждый игрок должн подойти к терминалу и сделать свой выбор. Для продолжения нажмите любую кнопку. ");
                Console.ReadKey(true);
                Console.Clear();

                //HO4b and Actions
                for (i = 0; i < ListOfPlayers.Count; i++)
                {
                    Console.WriteLine("Введите ваш номер игрока, чтобы сделать выбор.");
                Night:
                    try { buff = Convert.ToInt32(Console.ReadLine()); }
                    catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto Night; }
                    if (!ListOfPlayers.ContainsKey(buff - 1)) { Console.WriteLine("Такого игрока нет или он уже выбыл. Попробуйте ввести ещё раз. "); goto Night; }

                    switch (ListOfPlayers[buff - 1])
                    {
                        case "Mafia": { ListChoosed.Add(ListChoosed.Count, ActionOfMafia(ListOfPlayers)); break; }
                        case "Innocent": { ActionOfInnocent(); break; }
                        case "Doctor": { DoctorChoose = ActionOfDoctor(ListOfPlayers); break; }
                        case "Commissioner": { ActionOfCommissioner(ListOfPlayers); break; }
                        default: { Console.WriteLine("Failed Successfully=(... How did it get in Default? "); break; }
                    }
                }
                LosedPlayer = ListChoosed[rnd.Next(ListChoosed.Count)];
                if (DoctorChoose == LosedPlayer) { LosedPlayer = 0; }
                Console.WriteLine(LosedPlayer == 0 ? "Этой ночью никто не выбывает из игры." : "Этой ночью из игры выбыл игрок " + LosedPlayer + ". Он был " + ListOfPlayers[LosedPlayer - 1] + ". ");
                if (LosedPlayer != 0) { ListOfPlayers.Remove(LosedPlayer - 1); }
                Console.WriteLine("Доктор лечил игрока " + DoctorChoose + ". ");
                ShowAllPlayersWithoutRoles(ListOfPlayers);

                if (!(ListOfPlayers.Count > 2 && ListOfPlayers.ContainsValue("Mafia"))) { break; }

                //rOJlOCOBAHuE
                Console.WriteLine("\nТеперь начинается голосование");
                if (AnonVote) { AnonVoteYes(ListOfPlayers); }
                else { AnonVoteNot(ListOfPlayers); }
                ShowAllPlayersWithoutRoles(ListOfPlayers);

            }

            //Who win?
            if (ListOfPlayers.ContainsValue("Mafia")) { Console.WriteLine("\n\n\n\tMafia ВЫИГРАЛА эту игру.\n\n"); }
            else { Console.WriteLine("\n\n\n\tMafia ПРОИГРАЛА эту игру.\n\n"); }
            Console.WriteLine("Чтобы завершить эту игру, нажмите любую кнопку...");
            Console.ReadKey(true);
        }

        static Dictionary<string, int> GetNumberRolesList(int n)
        {
            Dictionary<string, int> ListOfRoles = new Dictionary<string, int>
            {
                { "Mafia", -1 },
                { "Innocent", -1 },
                { "Doctor", -1 },
                { "Commissioner", -1 }
            };
            switch (n)
            {
                case 3: { ListOfRoles["Mafia"] = 1; ListOfRoles["Innocent"] = 2; ListOfRoles["Doctor"] = 0; ListOfRoles["Commissioner"] = 0; break; }
                case 4: { ListOfRoles["Mafia"] = 1; ListOfRoles["Innocent"] = 2; ListOfRoles["Doctor"] = 1; ListOfRoles["Commissioner"] = 0; break; }
                case 5: { ListOfRoles["Mafia"] = 2; ListOfRoles["Innocent"] = 2; ListOfRoles["Doctor"] = 1; ListOfRoles["Commissioner"] = 0; break; }
                case 6: { ListOfRoles["Mafia"] = 2; ListOfRoles["Innocent"] = 2; ListOfRoles["Doctor"] = 1; ListOfRoles["Commissioner"] = 1; break; }
                case 7: { ListOfRoles["Mafia"] = 2; ListOfRoles["Innocent"] = 3; ListOfRoles["Doctor"] = 1; ListOfRoles["Commissioner"] = 1; break; }
                case 8: { ListOfRoles["Mafia"] = 3; ListOfRoles["Innocent"] = 3; ListOfRoles["Doctor"] = 1; ListOfRoles["Commissioner"] = 1; break; }
                case 9: { ListOfRoles["Mafia"] = 3; ListOfRoles["Innocent"] = 3; ListOfRoles["Doctor"] = 2; ListOfRoles["Commissioner"] = 1; break; }
                case 10: { ListOfRoles["Mafia"] = 3; ListOfRoles["Innocent"] = 4; ListOfRoles["Doctor"] = 2; ListOfRoles["Commissioner"] = 1; break; }
                default: { Console.WriteLine("Failed Successfully=(... How did it get in Default? "); break; }
            }

            return ListOfRoles;
        }

        static Dictionary<int, string> GetPlayersRolesList(Dictionary<string, int> ListOfRoles)
        {
            Random rnd = new Random();
            Dictionary<int, string> ListOfPlayers = new Dictionary<int, string>();
            int i, n = 0;
            foreach (int c in ListOfRoles.Values)
            {
                //Console.WriteLine(c);
                n += c;
            }
            int Buff;
            for (i = 0; i < n; i++)
            {
                Buff = rnd.Next(4);
                if (ListOfRoles[AssociationRoles(Buff)] > 0)
                {
                    ListOfPlayers[i] = AssociationRoles(Buff);
                    ListOfRoles[AssociationRoles(Buff)]--;
                }
                else { i--; }
            }
            return ListOfPlayers;
        }
        static string AssociationRoles(int a)
        {
            string S;
            switch (a)
            {
                case 0: { S = "Mafia"; break; }
                case 1: { S = "Innocent"; break; }
                case 2: { S = "Doctor"; break; }
                case 3: { S = "Commissioner"; break; }
                default: { S = "Error 404"; Console.WriteLine("Failed Successfully=(... How did it get in Default? "); break; }
            }
            return S;
        }
        static int ActionOfMafia(Dictionary<int, string> ListOfPlayers)
        {
            int Number;
            Console.WriteLine("Мафия должна сделать свой выбор... \nВведите номер игрока, которого вы считаете лишним в этой игре. Можете  также ввести '0', тогда вы никого не выберите.");
        MafiaChoose:
            try { Number = Convert.ToInt32(Console.ReadLine()); }
            catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto MafiaChoose; }
            if (Number == 0) { Console.WriteLine("Вы никого не выбрали."); }
            else if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте ввести ещё раз. "); goto MafiaChoose; }

            if (Number != 0) { Console.WriteLine("Выбор сделан. Судьба игрока " + Number + " будет решаться позже, если остались ещё игроки в команде Mafia, которые не проголосовали, или прямо сейчас..."); }
            Console.WriteLine("Если всё готово, то нажмите любую кнопку, затем передайте управление терминалом следующему игроку.");
            Console.ReadKey(true);
            Console.Clear();
            return Number;
        }
        static int ActionOfInnocent()
        {
            string Sbuff;
            Random rnd = new Random();
            Console.WriteLine("Введите что-нибудь...");
            Sbuff = Console.ReadLine();
            if (Sbuff == "220" || Sbuff == "The220th" || Sbuff == "the220th" || Sbuff == "220th") { Console.WriteLine("Made by 220th. Да да я=/\nНажми что-нибудь..."); Console.ReadKey(true); Console.Clear(); return 0; }
            else
            {
                switch (rnd.Next(15))
                {
                    case 0: { Console.WriteLine("Да... Мог бы и получше ввести что-нибудь."); break; }
                    case 1: { Console.WriteLine("Это нужно, чтобы сделать вид, что ты не Innocent. А то все что-то тыкают на клаве, а ты нет что ли?"); break; }
                    case 2: { Console.WriteLine("Хорошее времяпровождение тыкать на клавиши, учитывая, что это ничего не даст. Почти ничего..."); break; }
                    case 3: { Console.WriteLine("Говорят, что если ввести что-то определенное, то будет пасхалка. Но это не точно."); break; }
                    case 4: { Console.WriteLine("Если часто проигрываешь, то попробуй сменить свой метод убеждения. Например, пробуй доказать всем, что ты Mafia. Как минимум это интереснее."); break; }
                    case 5: { Console.WriteLine("Роли распределяются абсолютно случайным образом, так что один и тот же человек можек сколько угодно играть за Mafia."); break; }
                    case 6: { Console.WriteLine("Если какой-то игрок ни разу не голосовал за другого, то возможно они оба Mafia."); break; }
                    case 7: { Console.WriteLine(""); break; }
                    case 8: { Console.WriteLine("Найди n: \nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhnhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"); break; }
                    case 9: { Console.WriteLine("Тут может быть ваша реклама."); break; }
                    case 10: { Console.WriteLine("Теория вероятности тут не работает..."); break; }
                    case 11: { Console.WriteLine("Попробуй нахмуриться или сделать ухмылку, чтобы другие думали, что ты не просто тыкаешь на кнопки, а выбираешь жертву."); break; }
                    case 12: { Console.WriteLine("Yt yflj 'nj xbnfnm? njkmrj dhtvz gjnthztim/ Pfxtv& Djn gjnthzk? f cxf ,s e;t vju ,snm cktle.obq hfeyl///"); break; }
                    case 13: { Console.WriteLine("Попробуй в следующий раз, что-то ввести поинтереснее..."); break; }
                    case 14: { Console.WriteLine("Не тормози игру, не читай это и действуй дальше."); break; }
                    default: { Console.WriteLine("Странно, что вывелось это сообщение. Оно не должно быть здесь. Но даже, если оно вывелось, то это всё равно не критично..."); break; }
                }
                Console.WriteLine("Если готов играть дальше, то нажми любую кнопку...");
                Console.ReadKey(true);
                Console.Clear();

                return 0;
            }
        }
        static int ActionOfDoctor(Dictionary<int, string> ListOfPlayers)
        {
            int Number;
            Console.WriteLine("Вы должны выбрать кто точно не проиграет утром. Вы можете вылечить так же и себя. Введите номер игрока, которого вы хотите вылечить.");
        DoctorChoose:
            try { Number = Convert.ToInt32(Console.ReadLine()); }
            catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto DoctorChoose; }
            if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте ввести ещё раз. "); goto DoctorChoose; }

            Console.WriteLine("Если вы готовы играть дальше, то нажмите куда-нибудь и передайте управление следующему игроку...");
            Console.ReadKey(true);
            Console.Clear();
            return Number;
        }
        static void ActionOfCommissioner(Dictionary<int, string> ListOfPlayers)
        {
            int Number;
            Console.WriteLine("Вы должны выбрать за кем вы будет наблюдать ночью. Это раскроет вам, кто этот игрок. Выберите такого игрока.");
        CommissionerChoose:
            try { Number = Convert.ToInt32(Console.ReadLine()); }
            catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto CommissionerChoose; }
            if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте ввести ещё раз. "); goto CommissionerChoose; }
            Console.WriteLine("Вам удалось узнать, кто такой игрок " + Number);
            Console.WriteLine("\tИгрок " + Number + " это " + ListOfPlayers[Number - 1]);

            Console.WriteLine("Если вы готовы играть дальше, то нажмите какую-нибудь клавишу и передайте управление следующему игроку...");
            Console.ReadKey(true);
            Console.Clear();
        }
        static void ShowAllPlayersWighRoles(Dictionary<int, string> ListOfPlayers)
        {
            Console.WriteLine("Осталось игроков: ");
            foreach (int i in ListOfPlayers.Keys)
            {
                Console.WriteLine("Игрок " + (i + 1) + " " + ListOfPlayers[i]);
            }
        }
        static void ShowAllPlayersWithoutRoles(Dictionary<int, string> ListOfPlayers)
        {
            Console.WriteLine("\nОсталось игроков: ");
            foreach (int li in ListOfPlayers.Keys)
            {
                Console.WriteLine("Игрок " + (li + 1));
            }
        }
        static bool RuleOFEndGame(Dictionary<int, string> ListOfPlayers)
        {
            bool EndGame = false;
            if (ListOfPlayers.ContainsValue("Mafia") == false) { EndGame = true; Console.WriteLine("\n\n\n\tИгра закончилась. Mafia ПРОИГРАЛА.\n\n\n"); }
            if (ListOfPlayers.ContainsValue("Innocent") == false && ListOfPlayers.ContainsValue("Commissioner")) { EndGame = true; Console.WriteLine("\n\n\n\tИгра закончилась. Mafia ВЫИГРАЛА.\n\n\n"); }
            return EndGame;
        }
        static Dictionary<int, string> AnonVoteNot(Dictionary<int, string> ListOfPlayers)
        {
            Console.Write("Когда пройдет голосование, введите номер выбранного игрока: ");
            int Number;
        NotAnonChoose:
            try { Number = Convert.ToInt32(Console.ReadLine()); }
            catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto NotAnonChoose; }
            if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте ввести ещё раз. "); goto NotAnonChoose; }
            Console.WriteLine("Выбор сделан. \nИгрок " + Number + " играл за команду " + ListOfPlayers[Number - 1] + ". \nЭтот игрок выбывает из игры.");
            ListOfPlayers.Remove(Number - 1);
            return ListOfPlayers;
        }
        static Dictionary<int, string> AnonVoteYes(Dictionary<int, string> ListOfPlayers)
        {
            Console.WriteLine("Сейчас каждый оставшийся игрок должен подойти и проголосовать.");
            Console.WriteLine("Для продолжения нажмите любую кнопку...");
            Console.ReadKey(true);
            Console.Clear();

            //uHucuAJlu3Acu9 Vote
            Dictionary<int, int> Vote = new Dictionary<int, int>();
            foreach (int li in ListOfPlayers.Keys)
            {
                Vote.Add(li, 0);
            }

            //Main
            int Number;
            foreach (int li in ListOfPlayers.Keys)
            {
                Console.WriteLine("Введите ваш номер игрока: ");
            YesAnonVote:
                try { Number = Convert.ToInt32(Console.ReadLine()); }
                catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto YesAnonVote; }
                if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте ввести ваш номер игрока ещё раз. "); goto YesAnonVote; }

                Console.WriteLine("Теперь проголосуйте. Введите номер выбранного вами игрока: ");
            YesAnonChoose:
                try { Number = Convert.ToInt32(Console.ReadLine()); }
                catch { Console.WriteLine("Надо ввести цифру, а не букву. Введите ещё раз."); goto YesAnonChoose; }
                if (!ListOfPlayers.ContainsKey(Number - 1)) { Console.WriteLine("Такой игрок выбыл или его вообще нет. Попробуйте выбрать другого игрока. "); goto YesAnonChoose; }

                Vote[Number - 1]++;

                Console.WriteLine("Выбор сделан. Для продолжения нажмите любую кнопку...");
                Console.ReadKey(true);
                Console.Clear();
            }

            //Counting votes
            Random rnd = new Random();
            int max = 0;
            int nmax = -1;
            foreach (int li in Vote.Keys)
            {
                switch (rnd.Next(1))
                {
                    case 0: { if (Vote[li] > max) { max = Vote[li]; nmax = li; } break; }
                    case 1: { if (Vote[li] >= max) { max = Vote[li]; nmax = li; } break; }
                    default: { Console.WriteLine("Failed Successfully=(... How did it get in Default? "); break; }

                }

            }

            int Choosed = nmax;
            Console.WriteLine("Голосование проведено. Проигрывает игрок " + (Choosed + 1) + ". Он был " + ListOfPlayers[Choosed] + ". ");
            ListOfPlayers.Remove(Choosed);

            //End
            Console.WriteLine("Для продолжения нажмите любую кнопку...");
            Console.ReadKey(true);
            return ListOfPlayers;
        }
    }
}
